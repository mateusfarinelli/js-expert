module.exports = `
1º CONTRATANTE: Xuxa da Silva, brasileira, casada, CPF 235.743.420-12, residente e 
domiciliada a Rua dos bobos, zero, bairro Alphaville, São Paulo. 
CONTRATADA: Júlia Menezes, brasileira, solteira, CPF 297.947.800-81, residente e 
domiciliada a Av. dos Estados, 99, bairro Jardins, São Paulo. 

 
1ª CONTRATANTE:  
 
 
2ºCONTRATANTE:
 
 
CONTRATADA: 

`