class Base {
    constructor({ id, name }) {
        this.id = id
        this.name = name
    }
}

module.exports = Base